#include <stdio.h>

typedef struct student{
	int num;
	char name[20];
	float score;
}stu;

int main()
{
	stu s;
	char buf[128]="1001 xiongda 98.50";
	sscanf(buf,"%d%s%f",&s.num,s.name,&s.score);	
	printf("%d %s %5.2f\n",s.num,s.name,s.score);
	return 0;
}

