#include <unistd.h>
#include <stdio.h>

#define argc_check(a,b)  {if(a!=b){printf("error argc\n");return -1;}}
int main(int argc ,char **argv)
{
	char *p;
	p=getcwd(NULL,0);
	printf("p=%s\n",p);
	return 0;
}
