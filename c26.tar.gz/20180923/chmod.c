#include <unistd.h>
#include <stdio.h>
#include <sys/stat.h>

#define argc_check(a,b)  {if(a!=b){printf("error argc\n");return -1;}}
int main(int argc ,char **argv)
{
	argc_check(argc,2);
	char *p;
	int ret;
	ret =chmod  (argv[1],0666);
	if(-1==ret)
	{
			perror("chmod");
			return -1;
	}
	return 0;
}
