#include "func.h"

void sigfunc(int signum)
{
	printf("%d is coming \n",signum);
}

int main()
{
	if(signal(SIGUSR1,sigfunc)==SIG_ERR)
	{
		perror("signal");
	}
	while(1);
	return 0;
}
