#include "func.h"

int main()
{
	if(signal(SIGINT,SIG_IGN)==SIG_ERR)
	{
		perror("signal");
	}
	while(1);
	return 0;
}
