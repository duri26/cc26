#include "func.h"

void sigfunc(int signum)
{
	printf("before sleep %d is coming \n",signum);
	sleep(9);
	printf("after sleep %d is coming \n",signum);
}

int main()
{
if(signal(SIGINT,sigfunc)==SIG_ERR)
{
perror("signal");
}
signal(SIGQUIT,sigfunc);
while(1);
return 0;
}
