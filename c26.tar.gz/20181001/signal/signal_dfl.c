#include "func.h"

int main()
{
	if(signal(SIGINT,SIG_IGN)==SIG_ERR)
	{
		perror("signal");
	}
	sleep(9);
	signal(SIGINT,SIG_DFL);
	while(1);
	return 0;
}
