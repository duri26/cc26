#include "func.h"

void sigfunc(int signum)
{
	printf("%d is coming\n",signum);
}

int main()
{
	if(signal(SIGINT,sigfunc)==SIG_ERR)
	{
		perror("signal");
	}
	char buf[128]={0};
	read(0,buf,sizeof(buf));
	return 0;
}
