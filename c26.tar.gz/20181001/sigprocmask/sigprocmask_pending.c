#include "func.h"

int main()
{
	sigset_t mask;
	sigemptyset(&mask);
	sigaddset(&mask,SIGINT);
	int ret=sigprocmask(SIG_BLOCK,&mask,NULL);
	if(-1==ret)
	{
		perror("sigprocmask");
		return -1;
	}
	sleep(10); //关键代码
	sigset_t pend;
	sigemptyset(&pend);
	sigpending(&pend);
	if(sigismember(&pend,SIGINT))
	{
		printf("SIGINT is pending\n");
	}
	else
	{
		printf("SIGINT is not pending\n");
	}
	sigprocmask(SIG_UNBLOCK,&mask,NULL);
	return 0;
}
