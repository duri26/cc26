#include "func.h"

void sigfunc(int signum)
{
}

int main()
{
	signal(SIGALRM,sigfunc);
	alarm(6);
	pause(); //去睡眠队列
	return 0;
}

