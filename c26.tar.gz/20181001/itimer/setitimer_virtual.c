#include "func.h"

void sigfunc(int signum)
{
	time_t t;
	time(&t);
	printf("%s\n",ctime(&t));
}

int main()
{
	sigfunc(0);
	signal(SIGVTALRM,sigfunc);
	struct itimerval t;
	memset(&t,0,sizeof(t));
	t.it_value.tv_sec=6;
	t.it_interval.tv_sec=2;
	int ret;
	ret=setitimer(ITIMER_VIRTUAL,&t,NULL);
	if(-1==ret)
	{
		perror("setitimer");
		return -1;
		}
	sleep(4);
	while(1);
}
