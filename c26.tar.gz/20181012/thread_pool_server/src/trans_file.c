#include "factory.h"

void sigfunc(int signum)
{
	printf("%d is coming\n",signum);
}

int trans_file(int new_fd)
{
	train t;
	signal(SIGPIPE,sigfunc);

	t.data_len=strlen(FILENAME);
	strcpy(t.buf,FILENAME);
	int ret;
	ret=send_n(new_fd,(char*)&t,4+t.data_len);
	if(-1==ret)
	{
		goto end;
	}
	t.data_len=sizeof(off_t);
	struct stat buf;
	stat(FILENAME,&buf);
	memcpy(t.buf,&buf.st_size,sizeof(off_t));
	ret=send_n(new_fd,(char*)&t,4+t.data_len);
	if(-1==ret)
	{
		goto end;
	}

	int fd=open(FILENAME,O_RDONLY);
	if(-1==fd)
	{
		perror("open");
		return -1;
	}
	while(t.data_len=read(fd,t.buf,sizeof(t.buf)))
	{
		ret=send_n(new_fd,(char*)&t,4+t.data_len);
		if(-1==ret)
		{
			goto end;
		}
	}
	send_n(new_fd,(char*)&t,4);
end:
	close(new_fd);
}

