#include "factory.h"

void cleanup(void *p)
{
	pthread_mutex_t *mutex=(pthread_mutex_t *)p;
	pthread_mutex_unlock(mutex);
}

void* thread_func(void *p)
{
	pfactory_t pf=(pfactory_t )p;
	pque_t pq=&pf->que;
	pNode_t pdelete;
	while(1)
	{
		pthread_mutex_lock(&pq->mutex);
		pthread_cleanup_push(cleanup,&pq->mutex);
		if(pf->start_flag&&0==pq->que_size)
		{
			pthread_cond_wait(&pf->cond,&pq->mutex);
		}
		if(!pf->start_flag)
		{
			pthread_exit(NULL);
		}
		que_get(pq,&pdelete);
		pthread_mutex_unlock(&pq->mutex);
		pthread_cleanup_pop(0);//参数0,弹出不执行，也就是不再解锁
		trans_file(pdelete->new_fd);
		free(pdelete);
		pdelete=NULL;
	}
}

int exit_fds[2];
void sigfunc_exit(int signum)
{
	write(exit_fds[1],&signum,1);
	int status;
	wait(&status);
	if(WIFEXITED(status))
	{
		printf("exit value=%d\n",WEXITSTATUS(status));
	}
	exit(0);
}

int main(int argc,char **argv)
{
	args_check(argc,5);
	pipe(exit_fds);
	while(fork())
	{
		signal(SIGUSR1,sigfunc_exit);
		wait(NULL);//父进程没关闭读端，因为共用一个，关闭下次无关打开；
	}
	close(exit_fds[1]);
	factory_t f;

	int thread_num=atoi(argv[3]);
	int capacity=atoi(argv[4]);
	factory_init(&f,thread_num,capacity);
	factory_start(&f);
	int sfd=socket(AF_INET,SOCK_STREAM,0);
	struct sockaddr_in ser;
	memset(&ser,0,sizeof(ser));
	ser.sin_family=AF_INET;
	ser.sin_port=htons(atoi(argv[2]));
	ser.sin_addr.s_addr=inet_addr(argv[1]);
	int ret;
	int reuse=1;
	setsockopt(sfd,SOL_SOCKET,SO_REUSEADDR,&reuse,sizeof(int));
	ret=bind(sfd,(struct sockaddr*)&ser,sizeof(ser));
	if(-1==ret)
	{
		perror("bind");
		return -1;
	}
	int epfd=epoll_create(1);
	struct epoll_event event,evs[2];
	event.events=EPOLLIN;
	event.data.fd=sfd;
	epoll_ctl(epfd,EPOLL_CTL_ADD,sfd,&event);
	event.data.fd=exit_fds[0];
	epoll_ctl(epfd,EPOLL_CTL_ADD,exit_fds[0],&event);
	listen(sfd,2*thread_num);
	int new_fd;
	pque_t pq=&f.que;
	int fd_ready_num;
	int i;
	while(1)
	{
		fd_ready_num=epoll_wait(epfd,evs,2,-1);
		for(i=0;i<fd_ready_num;i++)
		{
			if(evs[i].data.fd==sfd)
			{
				new_fd=accept(sfd,NULL,NULL);
				pNode_t pnew=(pNode_t)calloc(1,sizeof(Node_t));
				pnew->new_fd=new_fd;
				pthread_mutex_lock(&pq->mutex);
				que_insert(pq,pnew);
				pthread_mutex_unlock(&pq->mutex);
				pthread_cond_signal(&f.cond);
			}
			if(evs[i].data.fd==exit_fds[0])
			{
				f.start_flag=0;
				for(i=0;i<f.thread_num;i++)
				{
					pthread_cond_signal(&f.cond);
				}
				for(i=0;i<f.thread_num;i++)
				{
					pthread_join(f.pth_arr[i],NULL);
				}
				exit(0);
			}
		}
	}
}

