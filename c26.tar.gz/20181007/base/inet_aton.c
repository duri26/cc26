#include "func.h"

int main(int argc,char **argv)
{
	args_check(argc,2);
	struct in_addr ip;
	int ret;
	ret=inet_aton(argv[1],&ip);
	printf("ip=%#x\n",ip.s_addr);
	printf("inet_addr ip=%#x\n",inet_addr(argv[1]));
	printf("string hostip=%s\n",inet_ntoa(ip));
	return 0;
}
