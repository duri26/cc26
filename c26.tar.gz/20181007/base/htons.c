#include "func.h"

int main()
{
	unsigned short port=0x1234;
	unsigned short net_port;
	net_port=htons(port);
	printf("net_port =%#x\n",net_port);
	return 0;
}
