#include "func.h"

int main()
{
	unsigned short port;
	unsigned short net_port=0x2345;
	port=ntohs(net_port);
	printf("net_port =%#x\n",port);
	return 0;
}
