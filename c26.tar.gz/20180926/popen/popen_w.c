#include "func.h"

int main()
{
	FILE *fp;
	fp=popen("./scanf","w");
	if(NULL==fp)
	{
		perror("popen:");
		return -1;
	}
	char buf[128]={"3 5"};
	fwrite(buf,sizeof(char),strlen(buf),fp);
	pclose(fp);
	return 0;
}
