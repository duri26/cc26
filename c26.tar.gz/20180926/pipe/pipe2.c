#include "func.h"

int main()
{
	int fds[2];
	pipe(fds);
	if(fork()>0)
	{
		close(fds[1]);
		char buf[128]={0};
		read(fds[0],buf,sizeof(buf));
		printf("I am parent ,buf =%s\n",buf);
		return 0;
	}
	else
	{
		close(fds[0]);
		printf("I am child\n");
		write(fds[1],"hello",5);
		wait(NULL);
		return 0;
	}
}
