#include "func.h"

int main()
{
	int fds[2];
	pipe(fds);
	if(!fork())
	{
		close(fds[1]);
		char buf[128]={0};
		read(fds[0],buf,sizeof(buf));
		printf("I am chlid ,buf =%s\n",buf);
		return 0;
	}
	else
	{
		close(fds[0]);
		printf("I am parent\n");
		sleep(5);
		write(fds[1],"hello",5);
		wait(NULL);
		return 0;
	}
}
