#include "func.h"

int main()
{
	int sem_id;
	sem_id=semget(1000,1,IPC_CREAT|0600);
	if(-1==sem_id)
	{
		perror("semget");
		return -1;
	}
	return 0;
}
