#include "func.h"

int main()
{
	pid_t pid;
	pid=fork();
	if(pid>0)
	{
		exit(0);
	}
	setsid();
	char buf[128];
	chdir("/");
	umask(0);
	int i;
	for(i=0;i<3;i+=2)
	{
		close(i);
	}
	while(1)
	{
		sleep(1);
		system("/home/duri/c26/20180926/deamon/syslog"); //因为文件夹位置改变，绝对路径
	}
}

