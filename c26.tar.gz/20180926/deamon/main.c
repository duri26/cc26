#include <stdlib.h>
int main(){
	system("./1");
}
