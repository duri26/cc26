#include "func.h"

void print()
{
	printf("I am print:\n");
exit(3);
}

int main()
{
	if(!fork())
	{
		print();
		printf("child \n");
	}
	else
	{
		printf("parent \n");
		int status;
		wait(&status);
		if(WIFEXITED(status))
		{
			printf("chlid exit code : %d\n",WEXITSTATUS(status));
			return 0;
		}
	}
}
