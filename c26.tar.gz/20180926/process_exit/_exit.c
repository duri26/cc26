#include "func.h"

void print()
{
	printf("I am print:");//无\n 不刷新缓存
_exit(3);//_exit 不刷新缓存
}

int main()
{
	if(!fork())
	{
		print();
		printf("child \n");
	}
	else
	{
		printf("parent \n");
		int status;
		wait(&status);
		if(WIFEXITED(status))
		{
			printf("chlid exit code : %d\n",WEXITSTATUS(status));
			return 0;
		}
	}
}
