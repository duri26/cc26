#include "func.h"

int main()
{
	int shmid;
	shmid=shmget(1000,4096,IPC_CREAT|0600);
	if(-1==shmid)
	{
		perror("shmget");
		return -1;
	}
	int ret;
	struct shmid_ds buf;
//	ret=shmctl(shmid,IPC_STAT,&buf);
//	if(-1==ret)
//	{
//		perror("shmctl");
//		return -1;
//	}
	printf("cuid=%d,mode=%o,shm_segsz=%ld,shm_nattch=%ld\n",buf.shm_perm.cuid,buf.shm_perm.mode,buf.shm_segsz,buf.shm_nattch);
return 0;
}
