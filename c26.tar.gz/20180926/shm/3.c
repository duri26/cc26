#include "func.h"

int main()
{
	int shmid;
	shmid=shmget(1000,4096,IPC_CREAT|0600);
	if(-1==shmid)
	{
		perror("shmget");
		return -1;
	}
	char *p;
	p=(char*)shmat(shmid,NULL,0);
	memset(p,0,4096);
	if((char*)-1==p)
	{
		perror("shmat");
		return -1;
	}
	printf("%s\n",p);
	if(!fork())
	{
		strcpy(p,"how are you");
		shmdt(p);
		exit(0);
	}
	else
	{
	//	sleep(1);
		wait(NULL);
printf("%s\n",p);
shmdt(p);
return 0;
	}
}

