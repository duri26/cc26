#include "func.h"

int main(int argc,char **argv)
{
	args_check(argc,2);
	key_t key;
	key=ftok("key=%d\n",key);
	printf("key=%d\n",key);
	return 0;
}
