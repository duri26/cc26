#include "func.h"
//获取进程组ID和设置进程组ID
int main()
{
	if(!fork())
	{
		printf("I am child,mypid=%d,ppid=%d,pgid=%d\n",getpid(),getppid(),getpgid(0));
		setpgid(0,0);
		printf("I am child,mypid=%d,ppid=%d,pgid=%d\n",getpid(),getppid(),getpgid(0));
		while(1);
	}else{
		printf("I am parent,mypid=%d,ppid=%d,pgid=%d\n",getpid(),getppid(),getpgid(0));
		while(1);
	}
}

