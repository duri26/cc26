#include "func.h"
//获取会话组ID和新建会话组
int main()
{
	if(!fork())
	{
		printf("I am child,mypid=%d,ppid=%d,pgid=%d,sid=%d\n",getpid(),getppid(),getpgid(0),getsid(0));
		setsid();
		printf("I am child,mypid=%d,ppid=%d,pgid=%d,sid=%d\n",getpid(),getppid(),getpgid(0),getsid(0));
	sleep(50);
	}else{
		printf("I am parent,mypid=%d,ppid=%d,pgid=%d,sid=%d\n",getpid(),getppid(),getpgid(0),getsid(0));
sleep(50);
	}
}

