#include <stdio.h>
#include <unistd.h>
#define check_argc(a,b) {if(a!=b){printf("error: argc\n");return -1;}}

int main(int argc,char **argv)
{
	check_argc(argc,3);
	char buf[90]={0};
	FILE *fp;
	sprintf(buf,"%s%s%s",argv[1],"/",argv[2]);
	chdir (argv[1]);
	fp =fopen(buf,"rb");
	if(NULL==fp)
	{
		perror("open:");
		return -1;
	}
	printf("%s\n",buf);
	return 0;
}	
