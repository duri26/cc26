#include "factory.h"

int recv_file(char *buf1,int sfd)
{
	int ret;
//printf("recv\n");

	char buf[1024]={0};

	int data_len;

	//	char buf[1000]={0};
//printf("jj\n");
	recv_n(sfd,(char*)&data_len,sizeof(int));

//printf("jjjj\n");
//	printf("1  %d\n",data_len);
	if(data_len<0)
	{
		//			printf("2   %d\n",data_len);
		goto too;

	}
	recv_n(sfd,buf,data_len);
	//接文件大小
	off_t file_size,download_size=0,before_download_size=0,compare_level;
	recv_n(sfd,(char*)&data_len,sizeof(int));
	recv_n(sfd,(char*)&file_size,data_len);

//printf("%s\n",buf);

	int fd=open(buf,O_WRONLY|O_CREAT,0700);
	compare_level=file_size/100;
	while(1)
	{
		ret=recv_n(sfd,(char*)&data_len,sizeof(int));
		if(-1==ret)
		{
			printf("recv error\n");
			break;
		}
		if(data_len>0)
		{
			ret=recv_n(sfd,buf,data_len);
			if(-1==ret)
			{
				printf("recv error\n");
				break;
			}


//printf("n   %s\n",buf);
			download_size=download_size+data_len;
			write(fd,buf,data_len);
			if(download_size-before_download_size>compare_level)
			{
				printf("%5.2f%s\r",(float)download_size*100/file_size,"%");
				fflush(stdout);
				before_download_size=download_size;
			if(download_size==file_size)
break;//只进来一次的情况
			}
		//	else
		//	{
		//		printf("%5.2f%s complete \n",(float)download_size*100/file_size,"%");
		//		break;
		//	}
		}
		else
		{
				printf("%5.2f%s complete \n",(float)download_size*100/file_size,"%");
			break;
		}
	}
		close(fd);	
too:
	printf("\n");
return 0;
}
