#include "factory.h"

int  func_cd(char *buf,int new_fd)
{
	int ret,i=2;
	char p[512]={0};
	while(buf[i]==' ')
	{
		i++;
	}
	ret=chdir(buf+i);
	if(-1==ret)
	{
//		printf("%s\n",buf+2);
		perror("chdir");
		send(new_fd,"error please input again: ",27,0);
		return 1;
	}
//	printf("cdp=%x\n",p);
//	p=getcwd(NULL,0);
	sprintf(p,"%s$",getcwd(NULL, 0));
//	printf("cdp=%x\n",p);
	send(new_fd,p,strlen(p),0);
	return 0;
}

int   func_ls(char *cur_dir,int new_fd)
{
	DIR *dir;
	struct dirent *link;
	struct stat buf;
	struct tm *p;
	char file_type[11] = {0};
	char t_buffer[128] = {0};
	char sbuf[512] = {0};

//	printf("%s\n", cur_dir);
	dir = opendir(cur_dir);
	while ((link = readdir(dir)) != NULL)
	{
		if (lstat(link -> d_name, &buf) == -1)
		{
//			printf("1\n");
	 	perror("lstat");
			continue;
		}
		if (strcmp(link -> d_name, ".") == 0 || strcmp(link -> d_name, "..") == 0)
		{
			continue;
		}
		strcpy(file_type, "----------");
		switch (buf.st_mode & S_IFMT)
		{
			case S_IFSOCK :
				file_type[0] = 's';
				break;
			case S_IFLNK :
				file_type[0] = 'l';
				break;
			case S_IFBLK :
				file_type[0] = 'b';
				break;
			case S_IFDIR :
				file_type[0] = 'd';
				break;
			case S_IFCHR :
				file_type[0] = 'c';
				break;
			case S_IFIFO :
				file_type[0] = 'p';
				break;
			default :
				break;
		}
		if (buf.st_mode & S_IRUSR)
		{
			file_type[1] = 'r';
		}
		if (buf.st_mode & S_IWUSR)
		{
			file_type[2] = 'w';
		}
		if (buf.st_mode & S_IXUSR)
		{
			file_type[3] = 'x';
		}
		if (buf.st_mode & S_IRGRP)
		{
			file_type[4] = 'r';
		}
		if (buf.st_mode & S_IWGRP)
		{
			file_type[5] = 'w';
		}
		if (buf.st_mode & S_IXGRP)
		{
			file_type[6] = 'x';
		}
		if (buf.st_mode & S_IROTH)
		{
			file_type[7] = 'r';
		}
		if (buf.st_mode & S_IWOTH)
		{
			file_type[8] = 'w';
		}
		if (buf.st_mode & S_IXOTH)
		{
			file_type[9] = 'x';
		}
		p = gmtime((time_t *)&(buf.st_mtim));
		p->tm_hour=p->tm_hour+8;
		strftime(t_buffer, 128, "%b %e %H:%M", p);
		sprintf(sbuf,"%-10s %3d %-6s %-6s %8lu %s %s%s",file_type,(int)buf.st_nlink,getpwuid(buf.st_uid)->pw_name,getgrgid(buf.st_gid)->gr_name,(long)buf.st_size,t_buffer,link->d_name,"\n");
//		printf("%s", sbuf);
	send(new_fd,sbuf,strlen(sbuf),0);
//	usleep(1);
	
memset(sbuf,0,sizeof(sbuf));
	}
//	func_pwd(new_fd);
	char k[512]={0};
//	printf("k=%x\n",k);
	sprintf(k,"%s$",getcwd(NULL,0));
//	printf("k=%x\n",k);
	send(new_fd,k,strlen(k),0);
	return 0;
}

int  func_pwd(int new_fd)
{
	char p[512]={0};
//	p=getcwd(NULL,0);
	sprintf(p,"%s%s%s%s",getcwd(NULL,0),"\n",getcwd(NULL,0),"$");
	send(new_fd,p,strlen(p),0);
	return 0;
}


int func_mkdir(char *buf,int new_fd)
{
int ret,i=5;
char p[512]={0};
while(buf[i]==' ')
{
	i++;
}
ret=mkdir(buf+i,0700);
if(-1==ret)
{
	perror("mkdir");
	send(new_fd,"error please input again: ",27,0);
	return 1;
}
	sprintf(p,"%s$",getcwd(NULL,0));
	send(new_fd,p,strlen(p),0);
return 0;
}

int func_rmdir(char *buf,int new_fd)
{
int ret,i=5;
char p[512]={0};
while(buf[i]==' ')
{
	i++;
}
ret=rmdir(buf+i);
if(-1==ret)
{
	perror("rmdir");
	send(new_fd,"error please input again: ",27,0);
	return 1;
}
	sprintf(p,"%s$",getcwd(NULL,0));
	send(new_fd,p,strlen(p),0);
return 0;
}

int func_unlink(char *buf,int new_fd)
{
int ret,i=2;
char p[512]={0};
while(buf[i]==' ')
{
	i++;
}
ret=unlink(buf+i);
if(-1==ret)
{
	perror("unlink");
	send(new_fd,"error please input again: ",27,0);
	return 1;
}
	sprintf(p,"%s$",getcwd(NULL,0));
	send(new_fd,p,strlen(p),0);
return 0;
}

int main(int argc,char **argv)
{
	args_check(argc,3);
	int sfd;
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(-1==sfd)
	{
		perror("socket");
		return -1;
	}
	struct sockaddr_in ser;
	memset(&ser,0,sizeof(ser));
	ser.sin_family=AF_INET;
	ser.sin_port=htons(atoi(argv[2]));
	ser.sin_addr.s_addr=inet_addr(argv[1]);
	printf("server ip =%s\n",inet_ntoa(ser.sin_addr));
	int ret;
	int reuse=1;
	setsockopt(sfd,SOL_SOCKET,SO_REUSEADDR,&reuse,sizeof(int));
	ret=bind(sfd,(struct sockaddr*)&ser,sizeof(ser));
	if(-1==ret)
	{
		perror("bind");
		return -1;
	}
	listen(sfd,10);
	int new_fd;
	struct sockaddr_in client;
	int len=sizeof(client);
	char buf[128]={0};
	int epfd=epoll_create(1);
	struct epoll_event event,evs[3];
	event.events=EPOLLIN;
	event.data.fd=STDIN_FILENO;
	ret=epoll_ctl(epfd,EPOLL_CTL_ADD,STDIN_FILENO,&event);
	if(-1==ret)
	{
		perror("epoll_ctl");
		return -1;
	}
	event.events=EPOLLIN;
	event.data.fd=sfd;
	ret=epoll_ctl(epfd,EPOLL_CTL_ADD,sfd,&event);
	if(-1==ret)
	{
		perror("epoll_ctl2");
		return -1;
	}
	int i;
	int ret_num;
	while(1)
	{
		memset(evs,0,sizeof(evs));
		ret_num=epoll_wait(epfd,evs,3,-1);
		for(i=0;i<ret_num;i++)
		{
			if(evs[0].data.fd==sfd)
			{
				new_fd=accept(sfd,(struct sockaddr*)&client,&len);
				if(-1==new_fd)
				{
					perror("accept");
					return -1;
				}
				printf("client ip =%s ,client port=%d\n",inet_ntoa(client.sin_addr),ntohs(client.sin_port));
				event.data.fd=new_fd;
				epoll_ctl(epfd,EPOLL_CTL_ADD,new_fd,&event);
//	send(new_fd,"connect success\n",16,0);
			}
			if(evs[0].data.fd==new_fd)
			{
				memset(buf,0,sizeof(buf));
				ret=recv(new_fd,buf,sizeof(buf),0);
				if(0==ret)
				{
					printf("byebye\n");
					event.data.fd=new_fd;
					epoll_ctl(epfd,EPOLL_CTL_DEL,new_fd,&event);
					close(new_fd);
				}
				else if(!strncmp(buf,"cd",2))
				{
					func_cd(buf,new_fd);
				}
				else if(!strncmp(buf,"ls",2))
				{
					func_ls(getcwd(NULL,0),new_fd);
				}
				else if(!strncmp(buf,"pwd",3))
				{
					func_pwd(new_fd);
				}
				else if(!strncmp(buf,"mkdir",5))
				{
					func_mkdir(buf,new_fd);
				}
				else if(!strncmp(buf,"rmdir",5))
				{
					func_rmdir(buf,new_fd);
				}
				else if(!strncmp(buf,"rm ",3))
				{
					func_unlink(buf,new_fd);
				}
				else if(!strncmp(buf,"gets",4))
				{
					trans_file(buf,new_fd);
				}
				else if(!strncmp(buf,"puts",4))
				{
					recv_file(buf,new_fd);
				}
				else if(!strncmp(buf,"connec",6))
				{
					send(new_fd,"Welcome  :",10,0);
				}
				else
				{
				//	printf("%s\n",buf);
					send(new_fd,"error please input again: ",27,0);
				}
			}
			//			if(evs[0].data.fd==STDIN_FILENO)
			//			{
			//				memset(buf,0,sizeof(buf));
			//				ret=read(STDIN_FILENO,buf,sizeof(buf));
			//				if(0==ret)
			//				{
			//					printf("Server disconnected\n");
			//					close(new_fd);
			//					goto end;
			//				}
			//				send(new_fd,buf,strlen(buf)-1,0);
			//			}
		}
	}
end:
	close(sfd);
}

