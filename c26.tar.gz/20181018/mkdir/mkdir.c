#include "func.h"

int main(int argc,char **argv)
{
	mkdir(argv[1],0700);
	return 0;
}

