#include "func.h"

int main(int argc,char **argv)
	{
		//		args_check(argc,2);
		int ret;
		char *p;
		p=getcwd(NULL,0);
		printf("pwd:%5s\n",p);

		char buf[128]={0};
		char buf1[128]={0};
while(1)
{
memset(buf,0,sizeof(buf));
memset(buf1,0,sizeof(buf1));

	fgets(buf,sizeof(buf),stdin);
		memcpy(buf1,buf,strlen(buf)-1);
		ret=chdir(buf1);
//		printf("%s",buf);
		if(-1==ret)
		{
			perror("chdir");
			return -1;
		}
		p=getcwd(NULL,0);
		printf("pwd:%5s\n",p);
}
		return 0;
	}
