#ifndef __FACTORY_H__
#define __FACTORY_H__
#include "head.h"
#include "work_que.h"
#define FILENAME "file"
typedef struct{
		int data_len;//控制数据，火车头，记录火车装载内容长度
			char buf[1000];//火车车厢
}train;

typedef struct{
		pthread_t *pth_arr;
			int thread_num;
				pthread_cond_t cond;
					que_t que;
						short start_flag;//未启动为0，启动为1
}factory_t,*pfactory_t;
void* thread_func(void*);
void factory_init(pfactory_t,int,int);
void factory_start(pfactory_t);
int trans_file(char*,int);
int send_n(int,char*,int);
int recv_n(int,char*,int);
//新加的
int func_cd(char*,int);
int func_ls(char*,int);
int func_pwd(int);
int func_mkdir(char*,int);
int func_rmdir(char*,int);
int func_unlink(char*,int);



#endif

