#include "factory.h"

int f=0;

int main(int argc,char **argv)
{
	args_check(argc,3);
	int sfd;
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(-1==sfd)
	{
		perror("socket");
		return -1;
	}
	struct sockaddr_in ser;
	memset(&ser,0,sizeof(ser));
	ser.sin_family=AF_INET;
	ser.sin_port=htons(atoi(argv[2]));
	ser.sin_addr.s_addr=inet_addr(argv[1]);
	int ret;
	ret=connect(sfd,(struct sockaddr*)&ser,sizeof(ser));
	if(-1==ret)
	{
		perror("connect");
		return -1;
	}
	printf("connect success\n");
	send(sfd,"connect",7,0);

	fd_set readset;
	char buf[4096]={0};
	while(1)
	{
		FD_ZERO(&readset);
		FD_SET(STDIN_FILENO,&readset);
		FD_SET(sfd,&readset);
		ret=select(sfd+1,&readset,NULL,NULL,NULL);
		if(ret>0)
		{
			if(FD_ISSET(sfd,&readset))
			{
				memset(buf,0,sizeof(buf));
				if(f)
				{
					int data_len;
					//	char buf[1000]={0};
					recv_n(sfd,(char*)&data_len,sizeof(int));
					//printf("1  %d\n",data_len);
					if(data_len<0)
					{
									printf("2   %d\n",data_len);
						f=0;
						goto too;

					}
					recv_n(sfd,buf,data_len);
					//接文件大小
					off_t file_size,download_size=0,before_download_size=0,compare_level;
					recv_n(sfd,(char*)&data_len,sizeof(int));
					recv_n(sfd,(char*)&file_size,data_len);
					int fd=open(buf,O_WRONLY|O_CREAT,0666);
					compare_level=file_size/100;
					while(1)
					{
						ret=recv_n(sfd,(char*)&data_len,sizeof(int));
						if(-1==ret)
						{
							printf("recv error\n");
							f=0;
							break;
						}
						if(data_len>0)
						{
							ret=recv_n(sfd,buf,data_len);
							if(-1==ret)
							{
								printf("recv error\n");
								f=0;
								break;
							}
							download_size=download_size+data_len;
							write(fd,buf,data_len);
					
					
//					printf("%ld  b %ld\n",before_download_size,download_size);
							if(download_size-before_download_size>compare_level)
							{
								printf("%5.2f%s\r",(float)download_size*100/file_size,"%");
								fflush(stdout);
								before_download_size=download_size;
							}
						//	else
						//	{
						//		printf("%5.2f%s\n",(float)download_size*100/file_size,"%");
						//		f=0;
						//		break;
						//	}
						}
						else
						{
								printf("%5.2f%s\n",(float)download_size*100/file_size,"%");
							f=0;
							break;
						}
					}
						close(fd);	
					printf("\n");
				}
				else
				{
					ret=recv(sfd,buf,sizeof(buf)-1,0);//每次接受少一个，最后一个'\n'
					if(0==ret)
					{
						printf("byebye\n");
						break;
					}
					printf("%s",buf);
					fflush(stdout);
				}
				f=0;
			}
			if(FD_ISSET(STDIN_FILENO,&readset))
			{
too:
				memset(buf,0,sizeof(buf));
				ret=read(STDIN_FILENO,buf,sizeof(buf));
				if(0==ret)
				{
					printf("bye\n");
					break;
				}
				if(0==strncmp(buf,"gets",4))
				{
					f=1;
				}
				if(0==strncmp(buf,"puts",4))
				{
//char buf1[1024]={0};
//memcpy(buf1,buf,strlen(buf));

//					send(sfd,buf1,strlen(buf1)-1,0);
					trans_file(buf,sfd);
					goto too;
				}
				//				printf("3   %d\n",f);
				//				printf("3   %d\n",f);
				send(sfd,buf,strlen(buf)-1,0);
			}

		}
	}	
	close(sfd);
	return 0;
}


