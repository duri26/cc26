#include "func.h"

typedef struct
{
	pthread_mutex_t mutex;
	pthread_cond_t cond;
}data;

void* threadfunc(void *p)
{
	data *pd=(data*)p;
	int ret;
	pthread_mutex_lock(&pd->mutex);
	ret=pthread_cond_wait(&pd->cond,&pd->mutex);
	pthread_mutex_unlock(&pd->mutex);
	printf("pthread_cond_wait ret=%d\n",ret);
	pthread_exit(NULL);
}

int main()
{
	data d;
	pthread_mutex_init(&d.mutex,NULL);
	int ret;
	ret=pthread_cond_init(&d.cond,NULL);
	if(ret)
	{
		printf("
