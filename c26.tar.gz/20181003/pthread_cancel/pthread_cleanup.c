#include "func.h"  //有错误

void cleanup(void *p)
{
	printf("I am cleanup\n");
	free(p);
}

void* thread(void *p)
{
	char *p1=(char*)malloc(20);
	p1="hello";
	pthread_cleanup_push(cleanup,p1);
	sleep(1);
	pthread_exit(NULL);
	pthread_cleanup_pop(1);
	return(void*) p1;
}
int main()
{
	pthread_t pthid;
	int ret;
	ret=pthread_create(&pthid,NULL,thread,NULL);
	if(ret)
	{
		printf("pthread_create failed ret=%d\n",ret);
		return -1;
	}
	printf("I am main thread\n");
	ret=pthread_cancel(pthid);
	if(ret)
	{
		printf("pthread_cancel ret=%d\n",ret);
		return -1;
	}
	long pret;
	ret=pthread_join(pthid,(void**)&pret);
	if(ret)
	{
		printf("pthread_join ret=%d\n",ret);
		return -1;
	}
	printf("main thread %s\n",(char*)pret);//线程被cancel，join得到的返回值是-1
	return 0;
}

