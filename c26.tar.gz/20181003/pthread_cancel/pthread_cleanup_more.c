#include "func.h"

void cleanup1(void*p)
{
	printf("I am cleanup1\n");
}

void cleanup2(void*p)
{
	printf("I am cleanup2\n");
}

void* thread(void *p)
{
	pthread_cleanup_push(cleanup1,NULL);
	pthread_cleanup_push(cleanup2,NULL);
	sleep(1);
	pthread_exit(NULL);
	pthread_cleanup_pop(0);
	pthread_cleanup_pop(0);
}

int main()
{
	pthread_t pthid;
	int ret=pthread_create(&pthid,NULL,thread,NULL);
	if(ret)
	{
		printf("pthread_creat failed,ret=%d",ret);
		return -1;
	}
	printf("I am main thread\n");
//	ret=pthread_cancel(pthid);
	if(ret)
	{
		printf("pthread_cancel ,ret=%d",ret);
	}
	long pret;
	ret=pthread_join(pthid,(void**)&pret);
	printf("main thread %ld\n",pret);
	return 0;
}
