#include<pthread.h>
#include<unistd.h>
#include<stdio.h>

typedef struct
{
	pthread_mutex_t mutex;
	pthread_cond_t cond;
}data;

void cleanup(void*p)
{
	pthread_mutex_unlock((pthread_mutex_t *)p);
}

void * pthreadfunc(void *p)
{
	data*p1=(data*)p;
	pthread_mutex_lock(&p1->mutex);
	pthread_cleanup_push(cleanup,&p1->mutex);
	pthread_cond_wait(&p1->cond,&p1->mutex);
	printf("I am child thread \n");
	pthread_exit(NULL);
	pthread_cleanup_pop(1);
}

int main()
{
	pthread_t pthid;
	data d;
	pthread_mutex_init(&d.mutex,NULL);
	pthread_cond_init(&d.cond,NULL);
	pthread_create(&pthid,NULL,pthreadfunc,&d);
	usleep(2000);
	pthread_cond_signal(&d.cond);
	sleep(1);
	printf("I am main thread\n");
	pthread_join(pthid,NULL);
	pthread_mutex_destroy(&d.mutex);
	pthread_cond_destroy(&d.cond);
	return 0;
}
