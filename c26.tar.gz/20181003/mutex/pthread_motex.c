#include "func.h"
#define N 10000000

typedef struct
{
	int i;
	pthread_mutex_t mutex;
}data;

void *thread(void *p)
{
	data *pd=(data*)p;
	int i;
	for(i=0;i<N;i++)
{
	pthread_mutex_lock(&pd->mutex);
	pd->i=pd->i+1;
	pthread_mutex_unlock(&pd->mutex);
}
pthread_exit(NULL);
}

int main()
{
	data d;
	int ret;
	ret =pthread_mutex_init(&d.mutex,NULL);
	if(ret)
	{
		printf("pthread_mutex_init failed,ret=%d\n",ret);
		return -1;
	}
	pthread_t pthid;
	d.i=0;
	struct timeval start,end;
	gettimeofday(&start,NULL);
	pthread_create(&pthid,NULL,thread,&d);
	if(ret)
	{
		printf("pthread_create failed,ret=%d\n",ret);
		return -1;
	}
	int i;
	for(i=0;i<N;i++)
	{
		pthread_mutex_lock(&d.mutex);
		d.i=d.i+1;
		pthread_mutex_unlock(&d.mutex);
	}
	pthread_join(pthid,NULL);
	gettimeofday(&end,NULL);
	printf("sum=%d,use time =%ld\n",d.i,(end.tv_sec-start.tv_sec)*1000000+end.tv_usec-start.tv_usec);
	return 0;
}
