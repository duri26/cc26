#include "func.h"
#define N 10000000

typedef struct 
{
	int tickets;
	pthread_mutex_t mutex;
}data;

void *salewindow1(void *p)
{
	data *pd=(data *)p;
	int i=0;
	while(1)
	{
		pthread_mutex_lock(&pd->mutex);
		if(pd->tickets>0)
		{
			printf("salewindow1 start sale tickets %d\n",pd->tickets--);
			i++;
			printf("salewindow1 finish sale tickets %d\n",pd->tickets);
			pthread_mutex_unlock(&pd->mutex);
		}
		else
		{
			pthread_mutex_unlock(&pd->mutex);
		break;
		}
	}
	printf("salewindow1 sales %d\n",i);
	pthread_exit(NULL);
}


void *salewindow2(void *p)
{
	data *pd=(data *)p;
	int i=0;
	while(1)
	{
		pthread_mutex_lock(&pd->mutex);
		if(pd->tickets>0)
		{
			printf("salewindow2 start sale tickets %d\n",pd->tickets--);
			i++;
			printf("salewindow2 finish sale tickets %d\n",pd->tickets);
			pthread_mutex_unlock(&pd->mutex);
		}
		else
		{
			pthread_mutex_unlock(&pd->mutex);
		break;
		}
	}
	printf("salewindow2 sales %d\n",i);
	pthread_exit(NULL);
}

int main()
{
	data d;
int ret;
ret=pthread_mutex_init(&d.mutex,NULL);
if(ret)
{
	printf("pthread_mutex_init failed ret=%d\n",ret);
	return -1;
}
pthread_t pthid1,pthid2;
d.tickets=100000;
pthread_create(&pthid1,NULL,salewindow1,&d);
pthread_create(&pthid2,NULL,salewindow2,&d);
pthread_join(pthid1,NULL);
pthread_join(pthid2,NULL);
printf("I am main thread, %d\n",d.tickets);
return 0;
}
