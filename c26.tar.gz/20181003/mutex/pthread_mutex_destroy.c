#include "func.h"

typedef struct
{
	int i;
	pthread_mutex_t mutex;
}data;
#define N 10000000

void *threadfunc(void*p)
{
	data* pd=(data*)p;
	int ret;
	ret=pthread_mutex_trylock(&pd->mutex);
	if(!ret)
	{
		printf("I am child thread,lock success\n");
	}
	else 
	{
		printf("I am child thread,lock failed,ret=%d\n",ret);
	}
	pthread_exit(NULL);
}

int main()
{
	data d;
	int ret;
	ret=pthread_mutex_init(&d.mutex,NULL);
	if(ret)
	{
		printf("pthread_mutex_init failed ret=%d\n",ret);
		return -1;
	}
	pthread_t pthid;
	d.i=0;
	pthread_create(&pthid,NULL,threadfunc,&d);
	int i;
	pthread_mutex_lock(&d.mutex);
	pthread_join(pthid,NULL);
	pthread_mutex_unlock(&d.mutex);
	if(ret)
	{
		printf("pthread_mutex_destroy faided ret=%d\n",ret);
		return -1;
	}
	printf("I am main thread\n");
	return 0;
}
