#include "func.h"
#define N 10000000

typedef struct
{
	int i;
	pthread_mutex_t mutex;
}data;

void * threadfunc(void *p)
{
	data *pd=(data*)p;
	int ret;
	pthread_exit(NULL);
}

int main()
{
	data d;
	int ret;
	pthread_mutexattr_t mutex_attr;
	pthread_mutexattr_init(&mutex_attr);
	pthread_mutexattr_settype(&mutex_attr,PTHREAD_MUTEX_ERRORCHECK);
	ret=pthread_mutex_init(&d.mutex,&mutex_attr);
	if(ret)
	{
		printf("pthread_mutex_init failed ret=%d\n",ret);
		return -1;
	}
	pthread_t pthid;
	d.i=0;
	pthread_create(&pthid,NULL,threadfunc,&d);
	int i;
	pthread_mutex_lock(&d.mutex);
	ret=pthread_mutex_lock(&d.mutex);
	printf("pthread_mutex_lock failed ret=%d\n",ret);
	pthread_join(pthid,NULL);
	printf("I am main thread\n");
	return 0;
}
