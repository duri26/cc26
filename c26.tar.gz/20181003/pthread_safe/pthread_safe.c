#include "func.h"

void *threadfunc(void *p1)
{
	printf("I am child thread\n");
	char *p;
	time_t t;
p=	ctime(&t);
printf("child thread time =%s\n",p);
sleep(3);
printf("child thread time =%s\n",p);
pthread_exit(NULL);
}

int main()
{
	pthread_t pthid;
	pthread_create(&pthid,NULL,threadfunc,NULL);
	int ret;
	long thread_exit_code;
	sleep(3);
char*p;
time_t t;
	time(&t);
	p=ctime (&t);
	printf("main thread time =%s\n",p);
	ret=pthread_join(pthid,(void**)&thread_exit_code);
	if(ret)
	{
		printf("pthread_join failed ret=%d\n",ret);
		return -1;
	}
	printf("thread_exit_code =%ld\n",thread_exit_code);
	return 0;
}

