#include "func.h"

void *threadfunc(void *p)
{
	printf("I am child thread\n");
	pthread_exit(NULL);
}

int main()
{
	pthread_t pthid;
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);
	pthread_create(&pthid,&attr,threadfunc,NULL);
		int ret;
		long thread_exit_code;
	   ret=	pthread_join(pthid,(void**)&thread_exit_code);
	   if(ret)
	   {
		   printf("pthread_join failed ret=%d\n",ret);
		   return -1;
		   }
	   printf("thread_exit_code =%ld\n",thread_exit_code);
	   return 0;
}
