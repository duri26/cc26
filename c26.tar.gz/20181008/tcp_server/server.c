#include "func.h"

int main(int argc,char **argv)
{
	args_check(argc,3);
	int sfd;
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(-1==sfd)
	{
		perror("socker");
		return -1;
	}
	struct sockaddr_in ser;
	memset(&ser,0,sizeof(ser));
	ser.sin_family=AF_INET;
	ser.sin_port=htons(atoi(argv[2]));
	ser.sin_addr.s_addr=inet_addr(argv[1]);
	int ret;
	ret=bind(sfd,(struct sockaddr*)&ser,sizeof(ser));
	if(-1==ret)
	{
		perror("bind");
		return -1;
	}
	listen(sfd,10);
	int new_fd;
	struct sockaddr_in client;
	int len=sizeof(client);
	new_fd=accept(sfd,(struct sockaddr*)&client,&len);
	if(-1==new_fd)
	{
		perror("accept");
		return -1;
	}
	printf("client ip=%s,client port=%d\n",inet_ntoa(client.sin_addr),ntohs(client.sin_port));
	char buf[128]={0};
	ret=recv(new_fd,buf,sizeof(buf),0);
	printf("ret=%d,buf=%s\n",ret,buf);
	send(new_fd,"I am server",11,0);
	close(new_fd);
	close(sfd);
}
