#include "func.h"

int main(int argc,char **argv)
{
	args_check(argc,3);
	int sfd;
	sfd=socket(AF_INET,SOCK_DGRAM,0);
	if(-1==sfd)
	{
		perror("socket");
		return -1;
	}
	struct sockaddr_in ser;
	memset(&ser,0,sizeof(ser));
	ser.sin_family=AF_INET;
	ser.sin_port=htons(atoi(argv[2]));
	ser.sin_addr.s_addr=inet_addr(argv[1]);
	int ret;
	char buf[128]={0};
	int len=sizeof(struct sockaddr);
	ret=sendto(sfd,"h",1,0,(struct sockaddr*)&ser,sizeof(ser));
	fd_set readset;
	while(1)
	{
		FD_ZERO(&readset);
		FD_SET(STDIN_FILENO,&readset);
		FD_SET(sfd,&readset);
		ret=select(sfd+1,&readset,NULL,NULL,NULL);
		if(ret>0)
		{
			if(FD_ISSET(sfd,&readset))
			{
				memset(buf,0,sizeof(buf));
				ret=recvfrom(sfd,buf,sizeof(buf),0,(struct sockaddr*)&ser,&len);
				printf("%s\n",buf);
			}
			if(FD_ISSET(STDIN_FILENO,&readset))
			{
				memset(buf,0,sizeof(buf));
				read(STDIN_FILENO,buf,sizeof(buf));
				ret=sendto(sfd,buf,strlen(buf)-1,0,(struct sockaddr*)&ser,sizeof(ser));
			}
		}
	}
	close(sfd);
	return 0;
}
