#include "func.h"

int main(int argc,char **argv)
{
	args_check(argc,3);
	int sfd;
	sfd=socket(AF_INET,SOCK_DGRAM,0);
	if(-1==sfd)
	{
		perror("socket");
		return -1;
	}
	struct sockaddr_in ser;
	memset(&ser,0,sizeof(ser));
	ser.sin_family=AF_INET;
	ser.sin_port=htons(atoi(argv[2]));
	ser.sin_addr.s_addr=inet_addr(argv[1]);
	int ret;
	ret=sendto(sfd,"helloworld",10,0,(struct sockaddr*)&ser,sizeof(ser));
	char buf[128]={0};
	struct sockaddr_in ser_tmp;
	memset(&ser_tmp,0,sizeof(ser_tmp));
	int len=sizeof(ser_tmp);
	ret=recvfrom(sfd,buf,sizeof(buf),0,(struct sockaddr*)&ser_tmp,&len);
	printf("ret=%d,buf=%s\n",ret,buf);
	printf("ser_tmp ip=%s,ser_tmp port=%d\n",inet_ntoa(ser_tmp.sin_addr),ntohs(ser_tmp.sin_port));
	close(sfd);
	return 0;
}
