#include "func.h"

int main(int argc,char **argv)
{
	args_check(argc,3);
	int sfd;
	sfd=socket(AF_INET,SOCK_DGRAM,0);
	if(-1==sfd)
	{
		perror("socket");
		return -1;
	}
	struct sockaddr_in ser;
	memset(&ser,0,sizeof(ser));
	ser.sin_family=AF_INET;
	ser.sin_port=htons(atoi(argv[2]));
	ser.sin_addr.s_addr=inet_addr(argv[1]);
	int ret;
	ret=bind(sfd,(struct sockaddr*)&ser,sizeof(ser));
	if(-1==ret)
	{
		perror("bind\n");
		return -1;
	}
	struct sockaddr_in client;
	memset(&client,0,sizeof(client));
	int len=sizeof(client);
	char buf[128]={0};
	ret=recvfrom(sfd,buf,5,0,(struct sockaddr*)&client,&len);
	printf("ret =%d,buf=%s\n",ret,buf);
	printf("client ip=%s,client port=%d\n",inet_ntoa(client.sin_addr),ntohs(client.sin_port));
			ret=sendto(sfd,"world",5,0,(struct sockaddr*)&client,sizeof(client));
			printf("send ret=%d\n",ret);
			close(sfd);
			return 0;
			}
