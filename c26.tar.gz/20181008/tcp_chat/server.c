#include "func.h"

int main(int argc,char **argv)
{
	args_check(argc,3);
	int sfd;
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(-1==sfd)
	{
		perror("socker");
		return 0;
	}
	struct sockaddr_in ser;
	memset(&ser,0,sizeof(ser));
	ser.sin_family=AF_INET;
	ser.sin_port=htons(atoi(argv[2]));
	ser.sin_addr.s_addr=inet_addr(argv[1]);
	int ret;
	ret=bind(sfd,(struct sockaddr*)&ser,sizeof(ser));
	if(-1==ret)
	{
		perror("bind");
		return -1;
	}
	listen(sfd,10);
	int new_fd;
	struct sockaddr_in client;
	int len=sizeof(client);
	new_fd=accept(sfd,(struct sockaddr*)&client,&len);
	if(-1==ret)
	{
		perror("accept");
		return -1;
	}
	printf("client ip=%s,client port=%d\n",inet_ntoa(client.sin_addr),ntohs(client.sin_port));
	char buf[128]={0};
	fd_set readset;
	while(1)
	{
		FD_ZERO(&readset);
		FD_SET(STDIN_FILENO,&readset);
		FD_SET(new_fd,&readset);
		ret=select(new_fd+1,&readset,NULL,NULL,NULL);
		if(ret>0)
		{
			if(FD_ISSET(new_fd,&readset))
			{
				memset(buf,0,sizeof(buf));
				ret=recv(new_fd,buf,sizeof(buf),0);
				if(0==ret)
				{
					printf("byebye\n");
					break;
				}
				printf("%s\n",buf);
			}
			if(FD_ISSET(STDIN_FILENO,&readset))
			{
				memset(buf,0,sizeof(buf));
				ret=read(STDIN_FILENO,buf,sizeof(buf));
				if(0==ret)
				{
					printf("byebye\n");
break;
				}
				send(new_fd,buf,strlen(buf)-1,0);
			}
		}
	}
	close (new_fd);
	close (sfd);
}
