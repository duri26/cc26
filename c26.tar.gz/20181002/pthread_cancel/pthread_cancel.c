#include "func.h"

void *thread(void *p)
{
	printf("I am child thread\n");
	sleep(1);
	pthread_exit(NULL);
}

int main()
{
	pthread_t pthid;
	int ret;
	ret=pthread_create(&pthid,NULL,thread,NULL);
	if(ret)
	{
		printf("pthread_create failed,ret=%d\n",ret);
		return -1;
	}
	printf("I am main thread\n");
	ret=pthread_cancel(pthid);
	if(ret)
	{
		printf("pthread_cancel ret=%d\n",ret);
		return -1;
	}
	long pret;
	ret=pthread_join(pthid,(void**)&pret);
	if(ret)
	{
		printf("pthread_join ret=%d\n",ret);
		return -1;
	}
	printf("main thread %ld\n",pret);
	return 0;
}
