#include "func.h"

void cleanup(void *p)
{
	printf("I am cleanup\n");
	free(p);
}

void *thread(void*p)
{
	printf("I am child\n");
	char *p1=(char*)malloc(20);
	pthread_cleanup_push(cleanup,p1);
read(0,p1,20);
	sleep(1);
	pthread_exit(NULL);
	pthread_cleanup_pop(1);
}

int main()
{
	pthread_t pthid;
	int ret;
	ret=pthread_create(&pthid,NULL,thread,NULL);
	if(ret)
	{
		printf("pthread_create failed ,ret=%d\n",ret);
		return -1;
	}
	printf("I am main thread\n");
usleep(300);
	ret=pthread_cancel(pthid);
	if(ret)
	{
		printf("pthread_cancel ret=%d\n",ret);
		return -1;
	}
	long pret;
	ret=pthread_join(pthid,(void **)&pret);
	if(ret)
	{
		printf("pthread_join , ret=%d\n",ret);
		return -1;
	}
	printf("main thread %ld\n",pret);
	return 0;
}
