#include "func.h"

void *thread(void*p)
{
	printf("I am child thread,%ld\n",(long)p);
	return(void*) 7;
}

int main()
{
	pthread_t pthid;
	int ret;
	long i=10;
	ret=pthread_create(&pthid,NULL,thread,(void*)i);
	if(ret)
	{
		printf("pthread_create failed ret=%d\n",ret);
	}
	printf("I am main thread\n");
	void *pret;
	ret=pthread_join(pthid,&pret);
	if(ret)
	{
		printf("pthread_join failed  ret=%d\n",ret);
	}
	return 0;
}
