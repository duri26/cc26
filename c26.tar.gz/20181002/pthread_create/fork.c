#include "func.h"

int main()
{
	if(fork())
	{
	usleep(1);
		printf("I am parents\n");
	}
	else
	{
		printf("I am child\n");
	}
}
