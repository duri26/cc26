#include "func.h"

void *thread(void*p)
{
	int fd=*(int*)p;
	printf("I am child thread,%d\n",fd);
//	close(fd);
	return NULL;
}

int main()
{
	pthread_t pthid;
	int ret;
	int fd=open("file",O_RDWR);
	ret=pthread_create(&pthid,NULL,thread,&fd);
	if(ret)
	{
		printf("pthread_create failed, ret=%d",ret);
		return -1;
	}
	printf("I am main thread\n");
	void *pret;
	ret=pthread_join(pthid,&pret);
	if(ret)
	{
		printf("pthread_join ret=%d\n",ret);
	}
	char buf[128]={0};
	ret=read(fd,buf,sizeof(buf));
	printf("ret=%d,buf=%s\n",ret,buf);
	return 0;
}
