#include "func.h"

void * thread(void *p)
{
	int i=*(int *)p;
	printf("I am child thread,%d\n",i);
	i=i+5;
	return NULL;
	}

int main()
{
	pthread_t pthid ;
	int ret;
	int i=5;
	ret=pthread_create(&pthid,NULL,thread,&i);
	if(ret)
		{
			printf("pthread_create failed , ret=%d",ret);
			return -1;
		}
	printf("I am main thread\n");
	void *pret;
	ret=pthread_join(pthid,&pret);
	if(ret)
	{
		printf("pthread_join ret=%d\n",ret);
	}
	printf("main thread i=%d\n",i);
	return 0;
}
