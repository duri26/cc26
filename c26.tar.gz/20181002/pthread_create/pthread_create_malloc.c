#include "func.h"

void *thread(void *p)
{
	printf("I am child thread ,%s \n",(char*)p);
	strcpy((char*)p,"hello");
sleep(1);
//	free(p);
//	p=NULL;
	return NULL;
}

int main()
{
	pthread_t pthid;
	int ret;
	char *p=(char*)malloc(20);
	strcpy(p,"world");
	ret=pthread_create(&pthid,NULL,thread,p);
	if(ret)
	{
		printf("pthread_create failde ,ret=%d",ret);
		return -1;
	}
	printf("I am main thread\n");
	void *pret;
	ret=pthread_join(pthid,&pret);
	if(ret)
	{
		printf("pthread_join ret=%d\n",ret);
	}
	printf("I am main : %s\n",p);
free(p);
p=NULL;
	return 0;
}
