#include "func.h"

void * pthreadfunc (void * funcnum)
{
//usleep(100);
	printf("I am child\n");
}


int main()
{
pthread_t t;
pthread_create(&t,NULL,pthreadfunc,NULL);
//usleep(1);
printf("I am main\n");
usleep(1);
return 0;//关于子线程打印两次，因为太快，子线程的缓存还未清理，main 就要关闭，检查到缓存还有内容，随将其打印出来;
}
