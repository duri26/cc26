#include "func.h"

void *thread (void *p)
{
	printf("I am child thread,%ld \n",(long)p);
	return (void *) 2;
}

int main()
{
	pthread_t pthid;
	int ret;
	ret=pthread_create(&pthid,NULL,thread,(void*)1);
	if(ret)
	{
		printf("pthread_create failed,ret=%d\n",ret);
		return -1;
	}
	printf("I am main thread\n");
	long pret;
	ret=pthread_join(pthid,(void**)&pret);
	if(ret)
	{
		printf("pthread_join ,ret=%d\n",ret);
	}
	printf("main thread %ld\n",pret);
	return 0;
}
