#include "func.h"

void print()
{
	printf("I am print\n");
	pthread_exit((void*)6);
}

void *thread(void *p)
{
	printf("I am child thread\n");
	print();
	printf("I am child thread after print\n");
	return (void*)6;
}

int main()
{
	pthread_t pthid;
	int ret;
	ret=pthread_create(&pthid,NULL,thread,NULL);
	if(ret)
	{
		printf("pthread_create failed , ret=%d",ret);
		return -1;
	}
	printf("I am main thread\n");
	long pret;
	ret=pthread_join(pthid,(void**)&pret);
	if(ret)
		{
			printf("pthread_join ret=%d\n",ret);
		}
	printf("main thread %ld \n",pret);
	return 0;
}
	
