#include "func.h"

void *thread(void *p)
{
	char buf[128]="hello";
	printf("I am child thread, %s\n",buf);
	return buf;
}

int main()
{
	pthread_t pthid;
	int ret;
	ret=pthread_create(&pthid,NULL,thread,NULL);
	if(ret)
	{
		printf("pthread_create failed,ret=%d\n",ret);
		return -1;
	}
	printf("I am main thread\n");
	void *pret;
	ret=pthread_join(pthid,&pret);
	if(ret)
	{
		printf("pthread_join ,ret=%d\n",ret);
	}
	printf("main thread %s\n",(char*)pret);
	return 0;
}
