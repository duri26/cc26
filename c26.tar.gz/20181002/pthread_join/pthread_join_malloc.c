#include "func.h"

void* thread(void*p)
{
	char *p1=(char*)malloc(20);
	strcpy(p1,"hello");
	printf("I am child thread, %s \n",p1);
	return p1;
}

int main()
{
	pthread_t pthid;
	int ret=pthread_create(&pthid,NULL,thread,NULL);
	if(ret)
	{
		printf("pthread_create failed ,ret=%d",ret);
		return -1;
	}
	printf("I am main thread\n");
void *pret;
ret=pthread_join(pthid,&pret);
if(ret)
{
	printf("pthread_join ,ret=%d",ret);
}
printf("main thread %s \n",(char*)pret);
return 0;
}
