#include <mysql/mysql.h>
#include <stdio.h>
#include <string.h>

int main(int argc,char **argv)
{
	MYSQL *conn;
	MYSQL_RES *res;
	MYSQL_ROW row;
	char *server="localhost";
	char *user="root";
	char *password="1214";
	char *database="test3";
	char query[200]="insert into person3(firstname,lastname,age) values('li','bai',34),('zhu','ziqing',24);";
	int t,r;
	conn=mysql_init(NULL);
	if(mysql_real_connect(conn,server,user,password,database,0,NULL,0))
	{
		printf("Error connecting to database:%s\n",mysql_error(conn));
	}
	else
	{
		printf("connect ...\n");
	}
	t=mysql_query(conn,query);
	if(t)
	{
		printf("Error makig query:%s\n",mysql_error(conn));
	}
	else
	{
		printf("insert success\n");
	}
	mysql_close(conn);
	return 0;
}
