#include "func.h"

int main(int argc,char **argv)

{
	int i=atoi(argv[1]);
	int j=atoi(argv[2]);
	printf("I am programe , sum =%d\n",i+j);
	while(1);
}
