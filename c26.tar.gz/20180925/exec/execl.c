#include "func.h"

int main(int argc,char **argv)
{
	sleep(3);
	execl("./add","add","3","4",NULL);
	printf("you can not see me");
}
