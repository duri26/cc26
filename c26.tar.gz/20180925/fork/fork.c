#include "func.h"

int main()

{
	pid_t pid;
	pid=fork();
	if(0==pid)
	{
		printf("I am chlid process\n");
	}
	else
		{
			printf("I am parent process\n");
//			sleep(3);
		}
	return 0;
}
