#include "func.h"

int main()
{
	pid_t pid;
	char *p =(char*) malloc (20);
   strcpy(p,"hello");
pid =fork();
if(!fork())
{
	printf("I am child proccess ,%s,%p\n",p,p);
}else{
	printf("I am parent proccess,%s,%p\n",p,p);
	strcpy(p,"world");

printf("I am parent proccess,%s,%p\n",p,p);
sleep(1);
}
}
