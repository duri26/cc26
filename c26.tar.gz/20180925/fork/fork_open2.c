#include "func.h"

int main()

{
	pid_t pid;


	pid=fork();
	if(0==pid)
	{
		int fd=open("file",O_RDWR);
		if(-1==fd)
		{
			perror("open:");
			return -1;
		}
		printf("I am chlid process\n");
		char buf[128]={0};
		read(fd,buf,5);
		printf("I am child %s\n",buf);

	}
	else
	{
		int fd=open("file",O_RDWR);
		if(-1==fd)
		{
			perror("open:");
			return -1;
		}
		printf("I am parent process\n");
		//			sleep(3);
		char buf[128]={0};
		read(fd,buf,5);
		printf("I am parent %s \n",buf);
		sleep(1);
	}
	return 0;
}
