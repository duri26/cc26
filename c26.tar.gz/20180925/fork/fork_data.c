#include "func.h"
int i =12;
int main()
{
	pid_t pid;
	pid=fork();
	if(0==pid)
	{
		printf("I am child process,mypid=%d,ppid=%d\n",getpid(),getppid());
		printf("I am child,i=%d\n",i);
	}else{
		printf("I am parent process,mypid=%d,childpid=%d\n",getpid(),pid);
		printf("I am parent,i=%d\n",i);
		i=5;
		printf("I am parent,i=%d\n",i);
		sleep(1);
	}
}

