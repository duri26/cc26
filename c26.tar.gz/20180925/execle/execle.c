#include "func.h"

int main()
{
	char *envp[]={"PATH=/home/duri/",NULL};
	execle("./test","test",NULL,envp);
	return 0;
}
