#include "func.h"

int main()
{
	system("echo $PATH");
	return 0;
}
