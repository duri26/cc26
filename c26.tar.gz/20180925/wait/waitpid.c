#include "func.h"

int main()
{
	pid_t pid;
	if(!(pid=fork()))
	{
		printf("I am child pid=%d\n",getpid());
		printf("child execute over\n");
//		sleep(5);
		return 5;
	}else{
		printf("I am parent pid=%d\n",getpid());
		int status;
sleep(1);
		pid=waitpid(pid,&status,WNOHANG);
		if(pid>0)
		{
			if(WIFEXITED(status))
			{
				printf("child exit code=%d\n",WEXITSTATUS(status));
			}else{
				printf("child crash\n");
			}
		}
		printf("wait success,child pid=%d\n",pid);
		return 0;
	}
}

