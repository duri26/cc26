#include "func.h"

int main()
{
	if(!fork())
	{
		printf("I am child preccess pid =%d\n",getpid());
//		char *p =(char *)malloc(20);
//		p++;
//		free(p);
		printf("child execute over\n");
		return 3;
	}
	else 
	{
		printf("I am parent pid =%d\n",getpid());
		pid_t pid ;
		int status;
		pid =wait(&status);
		if(WIFEXITED(status))
		{
			printf("child exit code =%d\n",WEXITSTATUS(status));
		}
		else
		{
			printf("child crash\n");
		}
		printf("wait success,child pid=%d\n",pid);
		return 0;
	}
}
