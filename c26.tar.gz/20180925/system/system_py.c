#include "func.h"

int main()
{
	system("python print.py");
	printf("I am main\n");
	return 0;
}

