#include "func.h"

int main()
{
	system("sleep 10");
	printf("hello lalala :\n");
	return 0;
}
