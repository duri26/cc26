#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main()
{
	pid_t pid =fork();
	if(!pid)
	{
		printf("I am child proccess :mypid %d myppid %d\n",getpid(),getppid());
	}
	else
	{
		printf("I am parent proccess:mypid %d childpid %d\n",getpid(),pid);
		sleep(30);
		return 0;
	}
}
