#include "func.h"

void change_nonblock(int fd)
{
	int status;
	status=fcntl(fd,F_GETFL);
	status=status|O_NONBLOCK;
	fcntl(fd,F_SETFL,status);
}

int main()
{
	sleep(5);
	char buf[128]={0};
	int ret;
	change_nonblock(0);
	ret=read(0,buf,sizeof(buf));
	printf("ret=%d,errno=%d,buf=%s\n",ret,errno,buf);
	return 0;
}
