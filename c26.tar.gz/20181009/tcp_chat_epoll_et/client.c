#include "func.h"

int main(int argc,char **argv)
{
	args_check(argc,1);
	int sfd;
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(-1==sfd)
	{
		perror("socket");
		return -1;
	}
	struct sockaddr_in ser;
	memset(&ser,0,sizeof(ser));
	ser.sin_family=AF_INET;
	ser.sin_port=htons(atoi("2000"));
    ser.sin_addr.s_addr=INADDR_ANY;//inet_addr(argv[1]);
	//	ser.sin_port=htons(atoi(argv[2]));
	//	ser.sin_addr.s_addr=inet_addr(argv[1]);//IP地址的点分十进制转为网络字节序
	int ret;
	ret=connect(sfd,(struct sockaddr*)&ser,sizeof(ser));
	if(-1==ret)
	{
		perror("connect");
		return -1;
	}
	printf("connect success\n");
	fd_set readset;
	char buf[128]={0};
	while(1)
	{
		FD_ZERO(&readset);
		FD_SET(STDIN_FILENO,&readset);
		FD_SET(sfd,&readset);
		ret=select(sfd+1,&readset,NULL,NULL,NULL);
		if(ret>0)
		{
			if(FD_ISSET(sfd,&readset))
			{
				memset(buf,0,sizeof(buf));
				ret=recv(sfd,buf,sizeof(buf),0);
				if(0==ret)
				{
					printf("byebye\n");
					break;
				}
				printf("%s\n",buf);
			}
			if(FD_ISSET(STDIN_FILENO,&readset))
			{
				memset(buf,0,sizeof(buf));
				ret=read(STDIN_FILENO,buf,sizeof(buf));
				if(0==ret)
				{
					printf("byebye\n");
					break;
				}
				send(sfd,buf,strlen(buf)-1,0);
			}
		}
	}
	close(sfd);
	return 0;
}

