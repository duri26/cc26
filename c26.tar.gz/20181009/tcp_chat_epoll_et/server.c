#include "func.h"

void change_nonblock(int fd)
{
	int status;
	status=fcntl(fd,F_GETFL);
	status=status|O_NONBLOCK;
	fcntl(fd,F_SETFL,status);
}

int main(int argc,char **argv)
{
	args_check(argc,1);
	int sfd;
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(-1==sfd)
	{
		perror("socker");
		return -1;
	}
	struct sockaddr_in ser;
	memset(&ser,0,sizeof(ser));
	ser.sin_family=AF_INET;
	ser.sin_port=htons(atoi("2000"));
	ser.sin_addr.s_addr=INADDR_ANY;//inet_addr(argv[1]);
	int ret;
	int reuse=1;
	setsockopt(sfd,SOL_SOCKET,SO_REUSEADDR,&reuse,sizeof(int));
//十个字节触发读
	int rcvlow = 10;
	setsockopt(sfd, SOL_SOCKET, SO_RCVLOWAT, &rcvlow, sizeof(int));

	ret=bind(sfd,(struct sockaddr*)&ser,sizeof(ser));
	if(-1==ret)
	{
		perror("bind");
		return -1;
	}
	listen(sfd,128);
	int new_fd;
	struct sockaddr_in client;
	int len=sizeof(client);
	char buf[5]={0};
	int epfd=epoll_create(1);
	struct epoll_event event,evs[3];
	event.events=EPOLLIN;
	event.data.fd=STDIN_FILENO;
	ret=epoll_ctl(epfd,EPOLL_CTL_ADD,STDIN_FILENO,&event);
	if(-1==ret)
	{
		perror("opoll_ctl");
		return -1;
	}
	event.events=EPOLLIN;
	event.data.fd=sfd;
	ret=epoll_ctl(epfd,EPOLL_CTL_ADD,sfd,&event);
	int i;
	int ret_num;
	while(1)
	{
		memset(evs,0,sizeof(evs));
		ret_num=epoll_wait(epfd,evs,3,-1);
		for(i=0;i<ret_num;i++)
		{
			if(evs[i].data.fd==sfd)
			{
				new_fd=accept(sfd,(struct sockaddr*)&client,&len);
				if(-1==new_fd)
				{
					perror("accept");
					return -1;
				}
				printf("client ip=%s, client port=%d\n",inet_ntoa(client.sin_addr),ntohs(client.sin_port));
				event.data.fd=new_fd;
				change_nonblock(new_fd);
				event.events=EPOLLIN|EPOLLET;
				epoll_ctl(epfd,EPOLL_CTL_ADD,new_fd,&event);
			}
			if(evs[i].data.fd==new_fd)
			{
				while(1)
				{
					memset(buf,0,sizeof(buf));
					ret=recv(new_fd,buf,sizeof(buf)-1,0);
					if(0==ret)
					{
						printf("byebye\n");
						event.data.fd=new_fd;
						epoll_ctl(epfd,EPOLL_CTL_DEL,new_fd,&event);
						close(new_fd);
					}else if(ret>0){
						printf("%s",buf);
					}else{
						printf("\n");
						break;
					}
				}
			}
			if(evs[i].data.fd==STDIN_FILENO)
			{
				memset(buf,0,sizeof(buf));
				ret=read(STDIN_FILENO,buf,sizeof(buf));
				if(0==ret)
				{
					printf("byebye\n");
					close(new_fd);
					goto end;
				}
				send(new_fd,buf,strlen(buf)-1,0);
			}
		}
	}
end:
	close(sfd);
}

