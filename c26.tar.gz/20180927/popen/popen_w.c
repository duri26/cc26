#include <stdio.h>
#include <string.h>

int main()
{
	char buf[128]={"aa 11 22 33"};
FILE *fp=popen("wc-w","w");
fwrite(buf,sizeof(buf),1,fp);
pclose(fp);
return 0;
}
