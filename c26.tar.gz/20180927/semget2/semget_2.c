#include "func.h"

int main()
	{
		int sem_id;
		sem_id=semget(1000,2,IPC_CREAT|0600);
		if(-1==sem_id)
		{
			perror("semget");
			return -1;
		}
		unsigned short arr[2]={1,1};
		int ret;
		ret =semctl(sem_id,0,SETALL,arr);
		if(-1==ret)
		{
			perror("semctl1");
			return -1;
		}
		bzero(arr,sizeof(arr));//chushihua 0,wufanhuizhi
		ret=semctl(sem_id,0,GETALL,arr);
		if(-1==ret)
		{
			perror("semctl2");
			return -1;
		}
		printf("arr[0]=%d,arr[1]=%d\n",arr[0],arr[1]);
//  ret=  semctl(sem_id, 0, IPC_RMID);//销毁
//  if(-1==ret)
//  {
//	  perror("semctl3");
//	  return -1;
//  }
		return 0;
	}
