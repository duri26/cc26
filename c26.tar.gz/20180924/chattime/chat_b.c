#include "func.h"

int main(int argc,char **argv)
{
	args_check(argc,3);
	int fdr,fdw;
	fdw=open(argv[1],O_WRONLY);//以写的方式打开1号管道
	if(-1==fdw)
	{
		perror("open");
		return -1;
	}
	fdr=open(argv[2],O_RDONLY);//以读的方式打开2号管道
	if(-1==fdr)
	{
		perror("open1");
		return -1;
	}
	printf("chat_a fdr=%d,fdw=%d\n",fdr,fdw);
	int ret;
	char buf[128];
	fd_set readset;
	struct timeval t;
	while(1)
	{
		FD_ZERO(&readset);
		FD_SET(0,&readset);
		FD_SET(fdr,&readset);
		t.tv_sec=5;
		t.tv_usec=0;

		ret=select(fdr+1,&readset,NULL,NULL,&t);
		if(ret>0)
		{
			if(FD_ISSET(0,&readset))//说明标准输入可读
			{
				memset(buf,0,sizeof(buf));
				ret=read(STDIN_FILENO,buf,sizeof(buf));
				if(0==ret)//ctrl+d 结束输入返回0
				{
					printf("over chat\n");
					break;
				}
				write(fdw,buf,strlen(buf)-1);
			}
			if(FD_ISSET(fdr,&readset))//说明管道可读
			{
				memset(buf,0,sizeof(buf));
				ret=read(fdr,buf,sizeof(buf));
				if(0==ret)//代表写端断开，读端一直可读
				{
					printf("byebye\n");
					break;
				}
				puts(buf);
			}	
		}else
		{
			printf("I am sleeping\n");
		}

	}
	close(fdr);
	close(fdw);
	return 0;
}

