#include "func.h"

int main(int argc,chatr **argv)
{
	args_check(argc,3);
	int fdr,fdw;
	fdr=open(argv[1],0_RD0NLY);
	if(-1==fdr)
	{
		perror("open:");
		return -1;
	}
	fdw=open(argv[2],O_WRONLY);
	if(-1==fdw
