#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main()
{
	printf("pid:%d ppid:%d uid:%d gid:%d euid:%d egid:%d",getpid(),getppid(),getuid(),getgid(),geteuid(),getegid());
int fd=open("file",O_RDWR|O_CREAT,0775);
if(-1==fd)
{
	perror("open:");
	return -1;
}
write(fd,"hello",5);
close (fd);
	return 0;
}
