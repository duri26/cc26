#include "func.h"

struct msgbuf
{
	long mtype;
	char mtext[64];
};

int main()
{
	int msgid;
	msgid=msgget(1000,IPC_CREAT|0600);
	if(-1==msgid)
	{
		perror("msgget");
		return -1;
	}
	struct msgbuf buf;
	if(fork())
	{
	buf.mtype=1;
	strcpy(buf.mtext,"hell world ");
if(-1==msgsnd(msgid,&buf,strlen(buf.mtext),0))
		{
		perror("msgsnd");
		return -1;
		}
wait(NULL);
msgctl(msgid,IPC_RMID,NULL);
return 0;
	}
	else 
	{
sleep(9);
		memset(&buf,0,sizeof(buf));
		if(-1==msgrcv(msgid,&buf,sizeof(buf.mtext),1,0))
		{
			perror("msgrcv");
			return -1;
		}
		printf("%s\n",buf.mtext);
	sleep(9);
		exit(3);
	}
}
