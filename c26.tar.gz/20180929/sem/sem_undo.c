#include "func.h"

int main()
{
	int sem_id =semget(1001,1,IPC_CREAT|0600);
	if(-1==sem_id)
	{
		perror("semget");
		return -1;
	}

	unsigned short array[2]={0};
	int ret=semctl(sem_id,0,SETALL,array);
	if(-1==ret)
	{
		perror("semctl");
		return -1;
	}
	struct sembuf sopp,sopv;
	if(!fork())
	{
		sopp.sem_num=0;
		sopp.sem_op=-1;
		sopp.sem_flg=SEM_UNDO;
		while(1)
		{
			semop(sem_id,&sopp,1);
			printf("I am child , semval=%d\n",semctl(sem_id,0,GETVAL));
			sleep(1);
		}
	}
	else
	{
		sopv.sem_num=0;
		sopv.sem_op=1;
		sopv.sem_flg=SEM_UNDO;
		while(1)
		{
			semop(sem_id,&sopv,1);
			printf("I am parent , semval=%d\n",semctl(sem_id,0,GETVAL));
			sleep(1);
		}
	}

}
