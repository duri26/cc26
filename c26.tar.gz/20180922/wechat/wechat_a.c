#include "func.h"

int main(int argc ,char **argv)
{
	args_check(argc,3);
int fdr,fdw;
fdr =open(argv[1],O_RDONLY);
if(-1==fdr)
{
	perror("open:");
	return -1;
}
fdw =open (argv[2],O_WRONLY);
if(-1==fdw)
{
	perror("open2:");
	return -1;
}
printf("wechat_a fdr=%d,fdw=%d\n",fdr,fdw);
int ret;
char buf[128];
fd_set readset;
while(1)
{
FD_ZERO(&readset);
FD_SET(0,&readset);
FD_SET(fdr,&readset);
ret=select(fdr+1,&readset,NULL,NULL,NULL);
if(ret>0)
{
	if(FD_ISSET(0,&readset))
	{
		memset(buf,0,sizeof(buf));
		ret=read(STDIN_FILENO,buf,sizeof(buf));
		if(0==ret)
		{
			printf("byebye");
			break;
		}
	write(fdw,buf,strlen(buf)-1);
	}

if(FD_ISSET(fdr,&readset))
{
memset(buf,0,sizeof(buf));
ret=read(fdr,buf,sizeof(buf));
if(0==ret)
{
	printf("byebye\n");
	break;
}
puts(buf);
	}
}
}
close(fdr);
close(fdw);
return 0;
}
