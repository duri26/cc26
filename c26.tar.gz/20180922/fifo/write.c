#include "func.h"

int main(int argc,char **argv)
{
	args_check(argc,2);
	int fdw;
	fdw=open(argv[1],O_WRONLY);
	if(-1==fdw)
	{
		perror("open");
		return -1;
	}
	printf("fdw=%d\n",fdw);
	int i=52;
	int ret;
	ret=write(fdw,&i,sizeof(int));
	printf("ret=%d,i=%d\n",ret,i);
	return 0;
}
