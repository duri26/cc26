#include "func.h"

int main(int argc,char**argv)
{
	args_check(argc,3);
	int fdr,fdw;
	fdr=open(argv[1],O_RDONLY);
	if(-1==fdr)
	{
		perror("open");
		return -1;
	}
	fdw=open(argv[2],O_WRONLY);
	if(-1==fdw)
	{
		perror("open2");
		return -1;
	}

	printf("chat_a fdr=%d,fdw=%d\n",fdr,fdw);
	int ret;
	char buf[128];
	while(1)
	{
		memset(buf,0,sizeof(buf));
		read(STDIN_FILENO,buf,sizeof(buf));
		write(fdw,buf,strlen(buf)-1);
		memset(buf,0,sizeof(buf));
		ret=read(fdr,buf,sizeof(buf));
		puts(buf);
	}
	return 0;
}

