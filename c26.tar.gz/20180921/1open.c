#include <unistd.h>
#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>

int main(int argc,char **argv)
{
	int fd =open("argv[1]",O_WRONLY|O_CREAT,0755);
		if(-1==fd)
		{
			perror("open failed\n");
			exit(-1);
		}
}
