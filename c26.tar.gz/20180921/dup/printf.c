#include "func.h"

int main(int argc,char **argv)
{
	args_check(argc,2);
	int fd;//存文件描述符
	fd=open(argv[1],O_RDWR,0777);
	if(-1==fd)
	{
		perror("open");
		return -1;
	}
	printf("fd=%d\n",fd);
printf("printf 1\n");
	close(1);
	int fd1=dup(fd);
	printf("you can see me");
	return 0;
}

