#include "func.h"

int main(int argc,char **argv)
{
	args_check(argc,2);
	int fd;//存文件描述符
	fd=open(argv[1],O_RDWR);
	if(-1==fd)
	{
		perror("open");
		return -1;
	}
	printf("fd=%d\n",fd);
	int fd1=dup2(fd,1);
	printf("fd1=%d\n",fd1);
	printf("you can't see me\n");
	return 0;
}
