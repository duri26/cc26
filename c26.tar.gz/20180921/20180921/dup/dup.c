#include "func.h"

int main(int argc,char **argv)
{
	args_check(argc,2);
	int fd;//存文件描述符
	fd=open(argv[1],O_RDWR,0777);
	if(-1==fd)
	{
		perror("open");
		return -1;
	}
	printf("fd=%d\n",fd);
	int fd1=dup(fd);
	printf("fd1=%d\n",fd1);
	close(fd);
	char buf[128]={0};
	int ret;
	ret=read(fd1,buf,sizeof(buf));
	if(-1==ret)
	{
		perror("read");
		return -1;
	}
	printf("buf=%s\n",buf);
	return 0;
}

