#include "func.h"

int main()
{
	write(1,"hello",5);
	return 0;
}
