#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#define args_check(a,b) {if(a!=b){printf("error args\n");return -1;}}
