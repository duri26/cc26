#include "func.h"

int main(int argc,char **argv)
{
	args_check(argc,2);
	int fdr;
	fdr=open(argv[1],O_RDONLY);//打开时的阻塞
	if(-1==fdr)
	{
		perror("open");
		return -1;
	}
	printf("fdr=%d\n",fdr);
	int i=1;
	int ret;
	ret=read(fdr,&i,sizeof(int));
	printf("ret=%d,i=%d\n",ret,i);
	return 0;
}
