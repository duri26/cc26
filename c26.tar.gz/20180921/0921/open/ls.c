#include "func.h"


void 	file_power_char(mode_t mode,mode_t type,char c)
{
	if((mode&type)==type)
		printf("%c",c);
	else
		printf("-");
}

int main(int argc,char* argv[])
{
	args_check(argc,2);
	DIR *dir;
	dir=opendir(argv[1]);
	struct dirent *p;
	struct stat buf;
	char path[512];
	int ret;
	mode_t a;
	while(p=readdir(dir))
	{
		memset(path,0,sizeof(path));
		sprintf(path,"%s%s%s",argv[1],"/",p->d_name);
		ret=stat(path,&buf);
		if(-1==ret)
		{
			perror("stat");
			return -1;
		}

		if(strcmp(".",p->d_name)&&strcmp("..",p->d_name))
		{	if(S_ISREG(buf.st_mode))
			printf("-");
			else if(S_ISDIR(buf.st_mode))
				printf("d");

			a=buf.st_mode;
			int 			mode =buf.st_mode&0777;
			file_power_char(mode,S_IRUSR,'r');/*判断user有无读权限*/
			file_power_char(mode,S_IWUSR,'w');/*判断user有无写权限*/
			file_power_char(mode,S_IXUSR,'x');/*判断user有无可执行权限*/

			file_power_char(mode,S_IRGRP,'r');/*判断group有无读权限*/
			file_power_char(mode,S_IWGRP,'w');/*判断group有无写权限*/
			file_power_char(mode,S_IXGRP,'x');/*判断group有无可执行权限*/

			file_power_char(mode,S_IROTH,'r');/*判断other有无读权限*/
			file_power_char(mode,S_IWOTH,'w');/*判断other有无写权限*/
			file_power_char(mode,S_IXOTH,'x');/*判断other有无可执行权限*/
			printf(" %ld %s %s %ld %s %s\n",buf.st_nlink,getpwuid(buf.st_uid)->pw_name,getgrgid(buf.st_gid)->gr_name,buf.st_size,ctime(&buf.st_mtime),p->d_name);
		}	}
	return 0;	
}
