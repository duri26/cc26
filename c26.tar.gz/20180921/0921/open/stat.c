#include "func.h"
int main(int argc,char* argv[])
{
	args_check(argc,2);
	DIR *dir;
	dir=opendir(argv[1]);
	struct dirent *p;
	struct stat buf;
	char path[512];
	int ret;
	mode_t a;
	while(p=readdir(dir))
	{
		memset(path,0,sizeof(path));
		sprintf(path,"%s%s%s",argv[1],"/",p->d_name);
		ret=stat(path,&buf);
		if(-1==ret)
		{
			perror("stat");
			return -1;
		}
		if(S_ISREG(buf.st_mode))
			printf("-");
		else if(S_ISDIR(buf.st_mode))
			printf("d");

		a=buf.st_mode;
		buf.st_mode =buf.st_mode&0777;
		printf("%o %ld %s %s %ld %s %s\n",buf.st_mode,buf.st_nlink,getpwuid(buf.st_uid)->pw_name,getgrgid(buf.st_gid)->gr_name,buf.st_size,ctime(&buf.st_mtime),p->d_name);
	}
		printf("total: %o\n",a/4096);
	return 0;	
}
