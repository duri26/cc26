#include "func.h"

typedef struct student
{
	int num;
	char name[20];
	float age;
}st,*psr;


void 	print(char *a,int n)
{
	int *p1,i;
	char *p2;
	float *p3;
	for(i=0;i<n;i++)
	{
	p1 = (int *) a;
	p2 =a +sizeof(int);
	p3=(float*)(a+(sizeof(int)+20));
	printf("%-4d %-8s%5.2f\n",*p1,p2,*p3);
	a+=sizeof(st);
	}
	}

int main(int argc,char **argv)
{
	args_check(argc,2);
	st s[3]={101,"lili",90,109 , "leilei",89,103,"wanwan",98};
	int fd;
	fd=open(argv[1],O_RDWR|O_CREAT,0666);
	if(-1==fd)
	{
		perror("open");
		return -1;
	}
	printf("fd=%d\n",fd);
	int ret;
	ret=write(fd,s,sizeof(s));
	lseek(fd,0,SEEK_SET);
	char buf[128]={0};
	ret=read(fd,buf,sizeof(s));
	if(-1==ret)
	{
		perror("read");
		return -1;
	}
	print(buf,3);
	close(fd);
	return 0;
}


